SET NAMES UTF8;
DROP DATABASE IF EXISTS xm;
CREATE DATABASE xm CHARSET=UTF8;
USE xm;
 

-- 创建数据表
#用户信息表
CREATE TABLE xm_user(
	uid INT PRIMARY KEY AUTO_INCREMENT,
	uname VARCHAR(32),
	upwd VARCHAR(32),
	user_name VARCHAR(32),       #用户名 如我是小虾米
	avatar VARCHAR(128),         #用户头像
	gender INT                   #性别 0-男 1-女
);

#首页轮播图片
CREATE TABLE xm_index_carousel(
	cid INT PRIMARY KEY AUTO_INCREMENT,
	img VARCHAR(128),            #图片的路径
	title VARCHAR(64)            
);

#歌单表
CREATE TABLE xm_singlist(
	sid INT PRIMARY KEY AUTO_INCREMENT,
	title VARCHAR(64),
	details VARCHAR(128),		  #二级标题
	avatar VARCHAR(128),          #歌单头像					         
	introduce VARCHAR(128),       #歌单介绍
	sing VARCHAR(128)
);

#歌曲表
CREATE TABLE xm_sing(
	sid INT PRIMARY KEY AUTO_INCREMENT,
	sing VARCHAR(128),
	avatar VARCHAR(128),          #歌曲的头像
	lyric VARCHAR(128),           #歌词
	details VARCHAR(64),          #歌曲的二级标题
	singer VARCHAR(32),           #歌手
	album VARCHAR(64),            #歌曲专辑
	introduce VARCHAR(128)        #歌曲介绍
);


-- 把数据插入数据表
#向轮播图插数据
INSERT INTO xm_index_carousel VALUES
(1,'img/carousel/carousel01.jpg','Loss'),
(2,'img/carousel/carousel02.jpg','我 去 2 0 0 0 年'),
(3,'img/carousel/carousel03.jpg','四海'),
(4,'img/carousel/carousel04.jpg','Nowhere Now Here'),
(5,'img/carousel/carousel05.jpg','7 rings'),
(6,'img/carousel/carousel06.jpg','镜中大提琴'),
(7,'img/carousel/carousel07.jpg','Hat Trick');

#向歌单表插入数据
INSERT INTO xm_singlist VALUES
(),