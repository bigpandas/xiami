//引入express模块
const express=require('express');
//引入pool数据池
const pool=require('../pool.js');
//创建路由器
var router=express.Router();

//往路由器添加路由
//登录路由
router.get('/login',(req,res)=>{
	var $uname=req.query.uname;
	var $upwd=req.query.upwd;
	if (!$uname) {
		res.send('0');
		return;
	}
	if (!$upwd) {
		res.send('0');
		return;
	}
	var sql="select * from xm_user where uname=? and upwd=?";
	pool.query(slq,[$uname,$upwd],(err,result)=>{
		if (err) {throw err}
		res.send('1');
	});
});
//注册路由
router.post('/register',(req,res)=>{
	var obj=req.body;
	for(var key in obj){
		if (!obj[key]) {
			res.send('1');
			return;
		}
	}
	var sql="insert into xm_user set ?";
	pool.query(sql,[obj],(err,result)=>{
		if (err) {throw err}
		res.send(result);
	});
});
//查询路由
router.get('query',(req,res)=>{
	var $uid=req.query.uid;
	if (!$uid) {
		res.send('0');
		return;
	}
	var sql="select * from xm_user where uid=?";
	pool.query(sql,[$uid],(err,result)=>{
		if (err) {throw err}
		if (result.length>0) {
			res.send(result[0]);
		}else{
			res.send('0');
		}
	});
});
//导出路由器
module.exports=router;